const sql = require("./db.js");

// constructor
const Movie = function(movie) {
    this.Movie_Image = movie.Movie_Image;
    this.Movie_Name = movie.Movie_Name;
    this.Actor = movie.Actor;
    this.Release_Date = movie.Release_Date;
    this.Movie_BoxOffice = movie.Movie_BoxOffice;
};

Movie.create = (newMovie, result) => {
  sql.query("INSERT INTO Social_FilmyTadka_Database SET ?", newMovie, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    console.log("created Movie: ", { id: res.insertId, ...newMovie });
    result(null, { id: res.insertId, ...newMovie });
  });
};

Movie.findById = (id, result) => {
  sql.query(`SELECT * FROM Social_FilmyTadka_Database WHERE Sr_No = ${id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found Movie: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found Movie with the id
    result({ kind: "not_found" }, null);
  });
};

Movie.getAll = ( result) => {
  let query = "SELECT * FROM Social_FilmyTadka_Database";
/*
  if (title) {
    query += ` WHERE title LIKE '%${title}%'`;
  }
*/
  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("movies: ", res);
    result(null, res);
  });
};

Movie.updateById = (id, movie, result) => {
  sql.query(
    "UPDATE Social_FilmyTadka_Database SET Movie_Image = ?, Movie_Name = ?, Actor = ?,Release_Date = ?,Movie_BoxOffice = ? WHERE Sr_No = ?",
    [movie.Movie_Image,movie.Movie_Name,movie.Actor,movie.Release_Date,movie.Movie_BoxOffice, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows == 0) {
        // not found Movie with the id
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("updated Movie: ", { id: id, ...movie });
      result(null, { id: id, ...movie });
    }
  );
};

Movie.remove = (id, result) => {
  sql.query("DELETE FROM Social_FilmyTadka_Database WHERE Sr_No = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows == 0) {
      // not found Movie with the id
      result({ kind: "not_found" }, null);
      return;
    }

    console.log("deleted Movie with id: ", id);
    result(null, res);
  });
};

Movie.removeAll = result => {
  sql.query("DELETE FROM Social_FilmyTadka_Database", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} movies`);
    result(null, res);
  });
};

module.exports = Movie;