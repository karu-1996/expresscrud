const Movie = require("../models/movie.model.js");

// Create and Save a new Movie
exports.create = (req, res) => {
  
};

// Retrieve all Movie from the database (with condition).
exports.findAll = (req, res) => {
  
};

// Find a single Movie with a id
exports.findOne = (req, res) => {
  
};


// Update a Movie identified by the id in the request
exports.update = (req, res) => {
  
};

// Delete a Movie with the specified id in the request
exports.delete = (req, res) => {
  
};

// Delete all Movie from the database.
exports.deleteAll = (req, res) => {
  
};


 //                                                CREATE
//Create and Save a new Movie:
exports.create = (req, res) => {
    // Validate request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    // Create a Movie
    const movie = new Movie({
        Movie_Image: req.body.Movie_Image,
        Movie_Name: req.body.Movie_Name,
        Actor: req.body.Actor,
        Release_Date:req.body.Release_Date,
        Movie_BoxOffice:req.body.Movie_BoxOffice || false
    });
  
    // Save Movie in the database
    Movie.create(movie, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the movie."
        });
      else res.send(data);
    });
  };


//                                                    GETALL
  // Retrieve all Movies from the database (with condition).
exports.findAll = (req, res) => {
    //const title = req.query.title;
  
    Movie.getAll( (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving movie."
        });
      else res.send(data);
    });
  };
  


  //                                         GET BY ID
  // Find a single Movie by the id:
  exports.findOne = (req, res) => {
    Movie.findById(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Movie with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Movie with id " + req.params.id
          });
        }
      } else res.send(data);
    });
  };


  //                                                    UPDATE
//Update a Movie identified by the id in the request:
  exports.update = (req, res) => {
    // Validate Request
    if (!req.body) {
      res.status(400).send({
        message: "Content can not be empty!"
      });
    }
  
    console.log(req.body);
  
    Movie.updateById(
      req.params.id,
      new Movie(req.body),
      (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: `Not found Movie with id ${req.params.id}.`
            });
          } else {
            res.status(500).send({
              message: "Error updating Movie with id " + req.params.id
            });
          }
        } else res.send(data);
      }
    );
  };

  //                                       DELETE BY ID
 // Delete a Tutorial with the specified id in the request:
 exports.delete = (req, res) => {
    Movie.remove(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found movie with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Could not delete movie with id " + req.params.id
          });
        }
      } else res.send({ message: `movie was deleted successfully!` });
    });
  };

  //                                         DELETEALL
  //Delete all Tutorials from the database:

  exports.deleteAll = (req, res) => {
    Movie.removeAll((err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while removing all Movies."
        });
      else res.send({ message: `All Movies were deleted successfully!` });
    });
  };